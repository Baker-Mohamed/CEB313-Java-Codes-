import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/online_store?serverTimezone=UTC";
    private static final String USER = "root"; // Change if needed
    private static final String PASSWORD = "Baker202513server"; // Change if needed

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        conn.setCatalog("online_store"); // Ensure the correct database is selected
        return conn;
    }
}
