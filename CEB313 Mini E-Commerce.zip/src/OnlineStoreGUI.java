import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

// GUI Class
public class OnlineStoreGUI {
    private JFrame frame;
    private JTable productTable;
    private DefaultTableModel tableModel;
    private JTextField discountField;
    private JLabel totalLabel;
    private JComboBox<String> categoryDiscountComboBox;
    private ArrayList<Product> products = new ArrayList<>();

    public OnlineStoreGUI() {
        // Frame Setup
        frame = new JFrame("Online Store");
        frame.setSize(900, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setResizable(false);

        // Set custom icon for the JFrame window
        try {
            Image icon = ImageIO.read(new File("C:\\Users\\BAKER MOHAMED M.M\\Downloads\\ecom.jpeg"));  // Replace with your icon file
            frame.setIconImage(icon);  // Set the icon image
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Table Configuration
        String[] columns = {"Name", "Category", "Original Price", "Discounted Price", "Quantity"};
        tableModel = new DefaultTableModel(columns, 0);
        productTable = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                if (row % 2 == 0) {
                    c.setBackground(new Color(240, 240, 240));
                } else {
                    c.setBackground(Color.WHITE);
                }
                return c;
            }
        };

        productTable.setRowHeight(30);
        productTable.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(productTable);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Product Panel
        JPanel productPanel = new JPanel();
        productPanel.setLayout(new GridLayout(5, 2, 10, 10));

        JLabel nameLabel = new JLabel("Product Name:");
        JTextField nameField = new JTextField();
        JLabel categoryLabel = new JLabel("Category:");
        JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"Electronics", "Clothing", "Books"});
        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();
        JLabel quantityLabel = new JLabel("Quantity:");
        JTextField quantityField = new JTextField();
        JButton addButton = new JButton("Add Product");

        addButton.setBackground(new Color(0, 123, 255));
        addButton.setForeground(Color.WHITE);

        addButton.addActionListener(e -> {
            String name = nameField.getText();
            String category = (String) categoryComboBox.getSelectedItem();
            double price = Double.parseDouble(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());

            Product product;
            switch (category) {
                case "Electronics":
                    product = new Electronics(name, price, quantity);
                    break;
                case "Clothing":
                    product = new Clothing(name, price, quantity);
                    break;
                case "Books":
                    product = new Books(name, price, quantity);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown category: " + category);
            }

            products.add(product);
            tableModel.addRow(new Object[]{name, category, price, price, quantity});
            updateTotal();
        });

        productPanel.add(nameLabel);
        productPanel.add(nameField);
        productPanel.add(categoryLabel);
        productPanel.add(categoryComboBox);
        productPanel.add(priceLabel);
        productPanel.add(priceField);
        productPanel.add(quantityLabel);
        productPanel.add(quantityField);
        productPanel.add(new JLabel());
        productPanel.add(addButton);

        frame.add(productPanel, BorderLayout.NORTH);

        // Discount & Total Panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JLabel discountLabel = new JLabel("Discount (%):");
        discountField = new JTextField(5);
        JButton applyDiscountButton = new JButton("Apply Discount");
        totalLabel = new JLabel("Total: $0.00");

        JLabel categoryDiscountLabel = new JLabel("Select Category:");
        categoryDiscountComboBox = new JComboBox<>(new String[]{"Electronics", "Clothing", "Books"});

        JButton clearTableButton = new JButton("Clear Table");
        clearTableButton.setBackground(Color.RED);
        clearTableButton.setForeground(Color.WHITE);

        applyDiscountButton.setBackground(new Color(0, 123, 255));
        applyDiscountButton.setForeground(Color.WHITE);

        applyDiscountButton.addActionListener(e -> {
            double discountPercentage = Double.parseDouble(discountField.getText());
            String selectedCategory = (String) categoryDiscountComboBox.getSelectedItem();

            for (Product product : products) {
                if (product.getClass().getSimpleName().equals(selectedCategory)) {
                    product.applyDiscount(discountPercentage);
                }
            }

            updateTable();
            updateTotal();
        });

        clearTableButton.addActionListener(e -> {
            products.clear();
            tableModel.setRowCount(0);
            totalLabel.setText("Total: $0.00");
        });

        bottomPanel.add(categoryDiscountLabel);
        bottomPanel.add(categoryDiscountComboBox);
        bottomPanel.add(discountLabel);
        bottomPanel.add(discountField);
        bottomPanel.add(applyDiscountButton);
        bottomPanel.add(clearTableButton);
        bottomPanel.add(totalLabel);

        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    // Update Total Price Label
    private void updateTotal() {
        double total = 0;
        for (Product product : products) {
            total += product.calculateDiscountedPrice() * product.getQuantity();
        }
        totalLabel.setText(String.format("Total: $%.2f", total));
    }

    // Update Table with Discounted Prices
    private void updateTable() {
        tableModel.setRowCount(0);
        for (Product product : products) {
            tableModel.addRow(new Object[]{
                    product.getName(),
                    product.getClass().getSimpleName(),
                    product.getOriginalPrice(),
                    product.calculateDiscountedPrice(),
                    product.getQuantity()
            });
        }
    }

    public static void main(String[] args) {
        new OnlineStoreGUI();
    }
}