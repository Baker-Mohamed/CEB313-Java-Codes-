//BOOKS CLASS
class Books extends Product {
    public Books(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public void applyDiscount(double percentage) {
        resetPrice();
        if(quantity >= 5){
        this.price = originalPrice - (originalPrice * (percentage / 100)); }
        else {
            this.price = originalPrice - (originalPrice * (percentage/100));
        }
    }

    @Override
    public double calculateDiscountedPrice() {
        return price;
    }
}