//ELECTRONICS CLASS
class Electronics extends Product {
    public Electronics(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public void applyDiscount(double percentage) {
        resetPrice();
        if (percentage > 20) percentage = 20; //max discount for electronics
        this.price = originalPrice - (originalPrice * (percentage / 100));
    }

    @Override
    public double calculateDiscountedPrice() {
        return price;
    }
}
