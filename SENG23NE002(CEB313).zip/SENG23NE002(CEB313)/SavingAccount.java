public class SavingAccount {
    private static double annualInterestRate =0.0;
    private double savingBalance;

    //constructor initialise the saving account with default 0.0
    public SavingAccount(double initialBalance){
        if(initialBalance < 0){
            throw new IllegalArgumentException("Initial balance must be positive");
        }
        this.savingBalance = initialBalance;
    }
    //calculates monthly interest and add to savingBalance
    public double MonthlyInterest(){
        double monthlyInterest = (savingBalance*annualInterestRate)/12;
        savingBalance += monthlyInterest;
        return monthlyInterest;
    }

    //returns current savings
    public double getSavingBalance(){
        return savingBalance;
    }
    //modify annual interest rate
    public static void modifyInterestRate(double newRate){
        if(0.0 <= newRate && newRate <= 1.0){
            throw new IllegalArgumentException("Interest rate must be between 0.0 and 1.0 inclusive");
        }
        annualInterestRate = newRate;
    }

}
