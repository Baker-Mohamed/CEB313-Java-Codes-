public class RationalTest {
    public static void main(String[] args) {
        Rational rational1 = new Rational(1, 2);
        Rational rational2 = new Rational(1, 3);

        System.out.println("Rational1: " + rational1);
        System.out.println("Rational2: " + rational2);

        Rational sum = rational1.add(rational2);
        System.out.println("Sum: " + sum);

        Rational difference = rational1.subtract(rational2);
        System.out.println("Difference: " + difference);

        Rational product = rational1.multiply(rational2);
        System.out.println("Product: " + product);

        Rational quotient = rational1.divide(rational2);
        System.out.println("Quotient: " + quotient);
    }
}
