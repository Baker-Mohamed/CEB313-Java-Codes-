public class ShapeTest {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[4];
        shapes[0] = new Circle(5);
        shapes[1] = new Rectangle(4, 6);
        shapes[2] = new Sphere(3);
        shapes[3] = new Cube(2);

        for (Shape shape : shapes) {
            System.out.println(shape.getDescription());
            if (shape instanceof TwoDimensionalShape) {
                TwoDimensionalShape twoDShape = (TwoDimensionalShape) shape;
                System.out.printf("Area: %.2f%n", twoDShape.getArea());
            } else if (shape instanceof ThreeDimensionalShape) {
                ThreeDimensionalShape threeDShape = (ThreeDimensionalShape) shape;
                System.out.printf("Area: %.2f%n", threeDShape.getArea());
                System.out.printf("Volume: %.2f%n", threeDShape.getVolume());
            }
            System.out.println();
        }
    }
}
