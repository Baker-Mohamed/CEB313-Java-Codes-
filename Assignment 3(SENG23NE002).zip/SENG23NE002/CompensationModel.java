
public interface CompensationModel {
    double earnings();
}