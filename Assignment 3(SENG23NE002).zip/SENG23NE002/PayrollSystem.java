import java.util.Calendar;

public class PayrollSystem {
    public static void main(String[] args) {
        // Create an array of Employee references
        Employee[] employees = new Employee[3];
        employees[0] = new SalariedEmployee("John Doe", new Date(15, 5, 1985), 60000);
        employees[1] = new SalariedEmployee("Jane Smith", new Date(20, 10, 1990), 72000);
        employees[2] = new SalariedEmployee("Alice Johnson", new Date(5, 5, 1988), 50000);

        // Get the current month
        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // Calendar.MONTH is 0-based

        // Calculate payroll for each employee
        for (Employee employee : employees) {
            double payroll = employee.calculatePayroll();
            // Check if the current month is the employee's birthday month
            if (employee.getBirthDate().getMonth() == currentMonth) {
                payroll += 100.00; // Add birthday bonus
            }
            System.out.printf("Payroll for %s: $%.2f%n", employee.getFirstName(), payroll);
        }
    }
}
