public class Employee {
    private String name;
    private CompensationModel compensationModel;

    public Employee(String name, CompensationModel compensationModel) {
        this.name = name;
        this.compensationModel = compensationModel;
    }

    public String getName() {
        return name;
    }

    public double earnings() {
        return compensationModel.earnings();
    }

    public void setCompensationModel(CompensationModel compensationModel) {
        this.compensationModel = compensationModel;
    }
}
