abstract class TwoDimensionalShape extends Shape {
    public abstract double getArea();
}