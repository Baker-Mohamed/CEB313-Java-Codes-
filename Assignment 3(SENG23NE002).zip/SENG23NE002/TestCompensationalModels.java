public class TestCompensationModels {
    public static void main(String[] args) {
        // Create Employee objects with different CompensationModels
        Employee salariedEmployee = new Employee("John Doe", new SalariedCompensationModel(800));
        Employee hourlyEmployee = new Employee("Jane Smith", new HourlyCompensationModel(15, 45));
        Employee commissionEmployee = new Employee("Jim Brown", new CommissionCompensationModel(10000, 0.1));
        Employee basePlusCommissionEmployee = new Employee("Jill White", new BasePlusCommissionCompensationModel(5000, 0.2, 300));

        // Display each Employee's earnings
        System.out.println(salariedEmployee.getName() + "'s earnings: " + salariedEmployee.earnings());
        System.out.println(hourlyEmployee.getName() + "'s earnings: " + hourlyEmployee.earnings());
        System.out.println(commissionEmployee.getName() + "'s earnings: " + commissionEmployee.earnings());
        System.out.println(basePlusCommissionEmployee.getName() + "'s earnings: " + basePlusCommissionEmployee.earnings());

        // Change each Employee's CompensationModel dynamically
        salariedEmployee.setCompensationModel(new HourlyCompensationModel(20, 40));
        hourlyEmployee.setCompensationModel(new SalariedCompensationModel(1000));
        commissionEmployee.setCompensationModel(new BasePlusCommissionCompensationModel(7000, 0.15, 500));
        basePlusCommissionEmployee.setCompensationModel(new CommissionCompensationModel(12000, 0.12));

        // Redisplay each Employee's earnings
        System.out.println("\nAfter changing compensation models:");
        System.out.println(salariedEmployee.getName() + "'s earnings: " + salariedEmployee.earnings());
        System.out.println(hourlyEmployee.getName() + "'s earnings: " + hourlyEmployee.earnings());
        System.out.println(commissionEmployee.getName() + "'s earnings: " + commissionEmployee.earnings());
        System.out.println(basePlusCommissionEmployee.getName() + "'s earnings: " + basePlusCommissionEmployee.earnings());
    }
}