abstract class Shape {
    public abstract String getDescription();
}
