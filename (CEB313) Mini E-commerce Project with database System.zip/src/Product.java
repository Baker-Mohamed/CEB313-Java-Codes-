//BASE PRODUCT CLASS
abstract class Product implements Discountable{
    protected String name;
    protected double originalPrice;//stores the original price
    protected double price;
    protected int quantity;

    public Product(String name,double price, int quantity){
        this.quantity = quantity;
        this.price = price;
        this.name = name;
        this.originalPrice = price;
    }
    public String getName(){
        return name;
    }
   public double getPrice(){
        return price;
   }
public double getOriginalPrice(){
        return originalPrice;
}
public int getQuantity(){
        return quantity;
}

public void resetPrice(){
        this.price = this.originalPrice;//resets price before applying a new discount
}

}
