
public class ECommerceAPP {
    public static void main(String[] args){
        //Creating the products
        Electronics TV = new Electronics("TV", 1500,2);
        Clothing pants = new Clothing("Pants",100,5);
        Books book = new Books("JAVA",10000,5);

        //displays initial prices
        System.out.println("Original Prices of Goods");
        System.out.println(TV);
        System.out.println(pants);
        System.out.println(book);
        System.out.println();

        //Applying discounts to various products
        TV.applyDiscount(5 );
        pants.applyDiscount(5);
        book.applyDiscount(2);

        //Display products after calculated discounts
        System.out.println(TV);
        System.out.println("Discounted price: $"+ TV.calculateDiscountedPrice());
        System.out.println();
        System.out.println(pants);
        System.out.println("Discounted price: $"+ pants.calculateDiscountedPrice());
        System.out.println();
        System.out.println(book);
        System.out.println("Discounted price: $"+ book.calculateDiscountedPrice());

    }
}