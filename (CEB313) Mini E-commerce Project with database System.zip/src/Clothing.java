//CLOTHING CLASS
class Clothing extends Product {
    public Clothing(String name, double price, int quantity) {
        super(name, price, quantity);
    }
    @Override
    public void applyDiscount(double percentage) {
        resetPrice();
        this.price = originalPrice - (originalPrice * (percentage / 100));
    }
    @Override
    public double calculateDiscountedPrice() {
        return price;
    }
}

