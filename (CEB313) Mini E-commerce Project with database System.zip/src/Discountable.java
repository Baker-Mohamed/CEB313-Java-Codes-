interface Discountable{
    void applyDiscount(double discountPercentage);
    double calculateDiscountedPrice();
}

